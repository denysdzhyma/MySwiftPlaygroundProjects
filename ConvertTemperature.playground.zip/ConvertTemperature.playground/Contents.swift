import UIKit

let celsius = 20 // Enter it to convert
let fahrenhit = 81 // Enter it to convert

let celsiusToFahrenhitFormula = (celsius * 9/5) + 32 // °F = (°C * 9/5) / 32
let fahrenhitToCelsiusFormula = (fahrenhit - 32) * 5/9 // °C = (°F - 32) * 5/9

let printMsgCelsiusToFahrenhit = "You entered \(celsius)°C. Your temperature is \(celsiusToFahrenhitFormula)°F."
let printMsgFahrenhitToCelsius = "You entered \(fahrenhit)°F. Your temperature is \(fahrenhitToCelsiusFormula)°C."

print(printMsgCelsiusToFahrenhit)
print(printMsgFahrenhitToCelsius)
