// Checkpoint 2 from https://www.hackingwithswift.com/quick-start/beginners/checkpoint-2

import UIKit

let carriers = ["Verizon Wireless", "T-Mobile", "AT&T", "Google Fi"]
let carriersCount = carriers.count
print("Total U.S. carriers: \(carriersCount).")

let nycAreaNumbers = Set([212, 332, 646, 917, 718, 347, 929]).sorted() // New York City, NY area
let nycAreaNumbersCount = nycAreaNumbers.count
print("Total in New York City has \(nycAreaNumbersCount) differents area numbers.")


